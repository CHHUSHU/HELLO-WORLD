import java.util.*;
/**
 * Write a description of class Sale here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sale
{
    private ProductList productList;
    private SaleTransaction transaction;
    private RandomNumberGenerator sale;
    /**Default constructor
     * 
     */
    public Sale()
    {
        productList = new ProductList();
        transaction = new SaleTransaction();
    }

    /**
     * non-default constructor
     */ 
    public Sale(ProductList newProductList, SaleTransaction newTransaction)
    {
        productList = newProductList;
        transaction = newTransaction;
    }

    /**
     * 
     */
    public ProductList getProductList()
    {
        return productList;
    }

    public SaleTransaction getTransaction()
    {
        return transaction;
    }

    /**
     * Mutator
     */
    public void setProductList()
    {

    }

    public void setSaleTransaction()
    {

    }

    public int genRandNo(int minimumValue, int maximumValue)
    {
        RandomNumberGenerator randomNo = new RandomNumberGenerator();
        return randomNo.random(minimumValue, maximumValue);
        /*int saleCode = randomNo.random(1000,9999);
         */

    }

    public void inputProduct(int i)
    {
        String name;
        String desc;
        double price;
        Scanner input = new Scanner(System.in);

        do
        {
            System.out.print("Name:");
            name = input.nextLine();    
        }
        while(name.length() < 3 || name.length() > 25 || (productList.compareName(name)));

        do
        {
            System.out.print("Description:");
            desc = input.nextLine();
        }
        while(desc.length() < 1 || desc.length() > 50);
        int warning = 0;
        do
        {
            warning = 0;
            System.out.print("Price:");
            String tempPrice = input.nextLine();
            for(int j = 0 ; j < tempPrice.length() ; j++)
            {
                if (!(Character.isDigit(tempPrice.charAt(j)) || tempPrice.charAt(j) == '.'))
                {
                    warning = 1;
                    break;
                }
            }
            if (warning == 1)
            {
                System.out.println("You must enter a number");
                price = 0;
            }
            else
                price = Double.parseDouble(tempPrice);
        } 
        while(price < 0 || warning == 1);

        int qtyOnHand = genRandNo(0,10);
        int miniOrderQty = genRandNo(1,5);

        addValue(i, name, desc, price, qtyOnHand, miniOrderQty);

    }

            
    public void addValue(int i, String name, String desc, double price, int qtyOnHand, int miniOrderQty)
    {
        productList.setSingleProductList(i, name, desc, price, qtyOnHand, miniOrderQty);
    }

    public void buyProduct(int customerInput)
    {   

        transaction.addItems(productList.getProductList(customerInput-1));

    }

    public boolean removeProduct(int deleteProduct)
    {   

        return transaction.removeItems(deleteProduct-1);

    }
    //public void finalCheckout()
    //{
    //  transaction
    //}
    //public void displayCart()
    //{   for(int i = 0; i < 3; i++)
    //   System.out.println(transaction.items[i]);
    //}

    public void startProgram()
    {
        String selection;
        int count = 0;
        int add = 0;
        int remove = 0;
        int numberOfProducts = 0;

        int option = 0;
        Scanner input = new Scanner(System.in);

        System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        System.out.println("Welcome to the Simple Inventory Management System");
        System.out.println("=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+");
        System.out.println("Please Select from the following options:");
        do
        {  
            System.out.println("Press 1 to Register a Product for Sale");
            System.out.println("Press 2 to Buy a Product for sale");
            System.out.println("Press 3 to Remove a Product to the chart");
            System.out.println("Press 4 to View all Available Products");
            System.out.println("Press 5 to Check out");
            System.out.println("Press 6 to Get Help");
            System.out.println("Press 7 to Exit");

            selection = input.nextLine();

            if (checkChar(selection))
            {

                // if (!(Character.isDigit(selection.charAt(0))&&selection.length()==1))
                //{

                //System.out.println("you must enter a integer");
                //continue;
                //}
                // option = input.nextInt();
                option = Integer.parseInt(selection);

                switch(option){
                    case 1: 
                    if(count >= 5)
                    {
                        System.out.println("ProductList is full");
                        break;
                    }
                    else{
                        inputProduct(count);
                        numberOfProducts += 1;
                        count ++;
                    }
                    break;

                    case 2: 

                    if(add - remove >= 3)
                    {
                        System.out.println("Cart is full");
                        break;
                    }

                    else{
                        if (numberOfProducts == 0)
                            System.out.println("No products added for sale.");
                        else{
                            System.out.println("Please select from the following products which are available:");
                            productList.displayForAdd();
                            int customerInput = input.nextInt();

                            if (customerInput >= 1 && customerInput <= 5 && customerInput <= numberOfProducts)
                            {
                                buyProduct(customerInput);
                                add ++;
                            }
                            else
                            {
                                System.out.println("There's no such product, Please choose from the available choice");
                                break;
                            }

                        }
                    }
                    break;

                    case 3:
                    if (remove >= add)
                    {
                        System.out.println("no more product to remove");
                    }
                    else
                    {
                        transaction.displayCart();
                        int deleteProduct = input.nextInt();
                        if (deleteProduct >= 1 && deleteProduct <= 3)
                        {
                            if(removeProduct(deleteProduct))
                                remove++;
                        }
                        else
                        {
                            System.out.println("There's no such product, Please choose from the available choice");
                            break;
                        }

                    }

                    break;

                    case 4: productList.displayAllProduct();

                    break;

                    case 5:checkOut();

                    break;
                    case 6: displayHelp();
                    break;
                    case 7: //System.exit(0); 
                    break;

                    default: System.out.println("Please select from option 1-7"); break;

                }
            }
            else
            {
                System.out.print("Please Enter a number \n");
            }

        } while(option != 7);

    }


    public boolean checkChar(String input)
    {
        if (input.length() == 0)
            return false;
        int location = 0;
        while (location < input.length())
        {
            char current = input.charAt(location);
            if (current < '0' || current > '9')
                return false;
            location++;
        }
        return true;
    }

    public void generateSaleCode()
    {
        int saleCode = genRandNo(1000,9999);
        System.out.println("Sale Code " + saleCode);
        transaction.setSaleCode(saleCode);
    }

    public void checkOut()
    {
        int check = transaction.testCheckOut();
        if (check == 0)
            System.out.println("You didnt have any item for check out");  
        else
        {
            generateSaleCode();
            transaction.finalSale();
            transaction.calcuFinal();
        }
    }

    public void displayHelp()
    {
        System.out.println("this is a help");

    }
}