import java.util.*;
/**
 * Write a description of class SaleTransaction here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SaleTransaction
{
    
   private int saleCode;
   private Product[] items;
   private double totalCost;

    /**
     * Default Constructor for objects of class SaleTransaction
     */
    public SaleTransaction()
    {
        items = new Product[3];
        saleCode = 0;
        totalCost = 0.0;
    }
    /**
     * Non-default constructor
     */
    public SaleTransaction(Product[] newItems, int newSaleCode, double newTotalCost)
    {
        items = newItems;
        saleCode = newSaleCode;
        totalCost = newTotalCost;
    }

    /**
     * 
     */
    public Product[] getItems()
    {
        return items; 
    }
    public int getSaleCode()
    {
       return saleCode;
    }
    
    public double getTotalCost()
    {
       return totalCost;
    }
    
    /**
     * Mutator method
     */
    public void setItems(Product[] newItems)
    {
        items = newItems;
    }
    
    public void setSaleCode(int newSaleCode)
    {
         saleCode = newSaleCode;
    }
    
    public void setTotalCost(double newTotalCost)
    {
        totalCost = newTotalCost;
    }
    
    public void addItems(Product productToAdd)
    {
        for (int i = 0 ; i < 3 ; i++)
        {
            if (items[i] == null)
            {
                items[i] = productToAdd;
                break;
            }
        }
    }
    
    public void displayCart()
    {   
        for(int j = 0; j < 3; j++)
        {   
            
            if (items[j] != null)
            {
                System.out.println("Select added Item" + (j + 1));
                items[j].displayProduct();
                
            }
        }
        
    }
    
    public boolean removeItems(int i)
    {
        while( i < 3)
        {
            if (items[i] != null)
            {
                items[i] = null;
                return true;
            }
            else
            {
               System.out.println("There's no such product, Please choose from the available choice");
               return false;
            }
          
        }  
        return false;
    }
   
    public void finalSale( )
    {
        for(int k = 0; k < 3; k++)
        {   
            
            if (items[k] != null)
            {
                System.out.println("Item" + (k + 1));
                items[k].displayProduct();
            }
        }
    }
    
    public int testCheckOut( )
    { 
       int numberOfProducts = 0;
        for(int k = 0; k < 3; k++)
        {   
            if (items[k] != null)
                numberOfProducts += 1;
        }
        return numberOfProducts;
    }
    
    public void calcuFinal()
    {   
        
        for(int a = 0; a < 3; a++)
        {
            if (items[a] != null)
            {
                double price = items[a].getPrice();
                int miniOrderQty =items[a].getMiniOrderQty();
                totalCost += price * miniOrderQty;
            }
        }
        System.out.println("The total value of your check out is:" + totalCost);
    }
    
 
}