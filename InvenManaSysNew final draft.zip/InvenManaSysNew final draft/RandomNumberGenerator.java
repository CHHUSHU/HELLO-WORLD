import java.util.Random;
/**
 * Write a description of class RandoNoGen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RandomNumberGenerator
{
    private int minimumValue;
    private int maximumValue;

    /**
     * Constructor for objects of class RandoNoGen
     */
    public RandomNumberGenerator()
    {
        minimumValue = 0;
        maximumValue = 0;
    }
    
    public RandomNumberGenerator(int newMinimumValue, int newMaximumValue)
    {
        minimumValue= newMinimumValue;
        maximumValue = newMaximumValue;
    }
    
    public int getMinimumValue()
    {
        return minimumValue;
    }
    
    public void setMinimumValue(int newMinimumValue)
    {
        minimumValue = newMinimumValue;
    }
    
    public int getMaximumValue()
    {
        return maximumValue;
    }
    
    public void setMaximumValue(int newMaximumValue)
    {
        maximumValue = newMaximumValue;
    }

    public int random(int minimumValue, int maximumValue)
    {
       return minimumValue + (int)(Math.random() * maximumValue);
    }
}
