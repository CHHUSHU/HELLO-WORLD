import java.util.*;
/**
 * This is a class that contains the products for registration
 * include information such as name, description, price. Quality on hand and minimum order quantity
 * @Chushu Tan
 * @version 8-15-2018
 */
public class Product
{
    private String name;
    private String desc;
    private double price;
    private int qtyOnHand;
    private int miniOrderQty;
    
    /**
     * Default Constructor for objects of class Product
     */
    public Product()
    {
       name = " ";
       desc = " ";
       price = 0;
       qtyOnHand = 0;
       miniOrderQty = 0;
    }
    
    
    /**
     * Non-default Constructor for objects of class product
     */
    public Product(String newName, String newDesc, double newPrice, int newQtyOnHand, int newMiniOrderQty)
    {
        name = newName;
        desc = newDesc;
        price = newPrice;
        qtyOnHand = newQtyOnHand;
        miniOrderQty = newMiniOrderQty;
        
    }
    
    /**
     * 
     *
     */
    public String getName()
    {
        return name;
    }
    
    public void setName(String newName)
    {
        name = newName;
    }
    
    public String getDesc()
    {
        return desc;
    }
    
    public void setDesc(String newDesc)
    {
        desc = newDesc;
    }
    
    public Double getPrice()
    {
        return price; 
    }
    
    public void setPrice(double newPrice)
    {
        price = newPrice;
    }
    
    public int getQuanOnHand()
    {
        return qtyOnHand;
    }
    
    public void setQtyOnHand(int newQtyOnHand)
    {
        qtyOnHand = newQtyOnHand;
    }
    
    public int getMiniOrderQty()
    {
        return miniOrderQty;
    }
    
    public void MiniOrderQty(int newMiniOrderQty)
    {
        miniOrderQty = newMiniOrderQty;
    }
    
    public void displayProduct()
    {
        
    	System.out.println("Name:" + name);
    	System.out.println("Description:"+ desc);
    	System.out.println("Price:" + price);
    	System.out.println("Quantity:" + qtyOnHand);
    	System.out.println("Mini Order Quantity:" + miniOrderQty);
    	
    }    
    
}
