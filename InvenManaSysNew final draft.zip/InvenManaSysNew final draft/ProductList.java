                                                                                                                                              /**
 /** Create a productList that register assign products into array
 *
 * @author Chushu Tan
 * @version (a version number or a date)
 */
public class ProductList
{
    //define field
    private Product[] productLists; 
    
    /**
     * Constructor for objects of class ProductList
     */
    public ProductList()
    {  
       productLists = new Product[5];
    }
    /**
     * non-default constructor
     */
    public ProductList(Product[] newProductLists)
    {
       productLists = newProductLists;
       
    }
    
    public void setProductList(Product[] newProductLists)
    {
        productLists = newProductLists;
    }
    
    public void setSingleProductList(int i,String name,String desc,double newPrice, int newQtyOnHand, int newMiniOrderQty)
    {
        productLists[i] = new Product(name, desc, newPrice, newQtyOnHand, newMiniOrderQty);
    }
    
    public Product getProductList(int i)
    {
        return productLists[i];
    }
    
    public void useProduct()
    {
    
        for(int i = 0; i < 5; i ++)
        {
            productLists[i] = new Product();
        }
 
    }
    
    public boolean compareName(String name)
    {
        for (int j = 0; j < 5; j++)
        {
            if(productLists[j] != null && productLists[j].getName().equalsIgnoreCase(name))
            {
                System.out.print("You have enter the same product");
                        return true;    
            }
        }  
        return false;  
    }
    
    public void displayAllProduct()
    {   
        int numberOfProducts = 0;
        for(int k = 0; k < 5; k++)
        {
            if (productLists[k] != null)
            {
                productLists[k].displayProduct();
                numberOfProducts += 1;
            }
        }
        if (numberOfProducts == 0)
            System.out.println("No products added for sale.");
    }
    
    public void displayForAdd()
    {   
        for(int k = 0; k < 5; k++)
        {
              
              if (productLists[k] != null)
            {   System.out.println("select product " + (k + 1));
                productLists[k].displayProduct();
                
            }  
        }
      
    }
    
        
      
        
        //for (int q)
        //inputProduct.getName();
        
        
    }
    
    
